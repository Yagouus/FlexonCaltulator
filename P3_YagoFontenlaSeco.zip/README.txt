//P3_YAGO FONTENLA SECO//

////PARA COMPILAR////
-Situarse sobre el directorio con todos los archivos necesarios (.c y .h)
-Ejecutar el comando "make"
-Se generará un ejecutable de nombre calculadora


////PARA EJECUTAR////
-Ejecutar el comando "./calculadora"
-El programa admite los parametros "--help" que muestra la ayuda del programa y "nombreFichero" que utiliza el fichero de ese nombre como entrada estandar
-Para que una instrucción se ejecute es necesario que termine en ";"

////SALIDA DEL PROGRAMA////
-Se mostrara la tabla de simbolos con su contenido inicial
-Se mostraran todas las operaciones realizadas
-Utilizando la opcion "exit" se termina el programa
-Se volvera a mostrar la tabla de simbolos con el contenido final
