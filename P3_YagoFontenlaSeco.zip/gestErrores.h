////TIPOS////
#define FICHERO "Error leyendo fichero"
#define DIVCERO "Division por cero"
#define INITVAR "Variable no inicializada"
#define NOTFUNC "Esa funcion no esta definida"
