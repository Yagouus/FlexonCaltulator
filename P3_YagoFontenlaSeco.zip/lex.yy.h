#include "tablaSimbolos.h"
#include "gestErrores.h"
#include "anaSintactico.tab.h"

compLex* anaLexico();
void leerArchivo(char* fichero);
