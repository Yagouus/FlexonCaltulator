#include <math.h>

//FUNCIONES
#define VARIABLE 1
#define FUNC 2
#define CONSTANT 3
